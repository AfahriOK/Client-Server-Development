from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = username
        PASS = password
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32437
        DB = 'aac'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
	          record = self.collection.insert_one(data)  # data should be dictionary 
	          return True if record.acknowledged else False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

# Create method to implement the R in CRUD.
    def read(self, query):
        if query is not None:
            records = list(self.collection.find(query, {'_id': 0})) # query should be a dictionary
        else:
            records = list(self.collection.find({}, {'_id': 0})) # will return all records in the collection
          
        return records
        
# Create method to implement the U in CRUD.
    def update(self, query, data):
        #query is what you are looking for and data is what you would like to input. Both should be a dictonary
        if query is not None and data is not None:
            if data is None:
                raise Exception("Nothing to update, because data parameter is empty")
            updatedRecords = self.collection.update_many(query, {"$set": data})
            return updatedRecords.modified_count
        else:
            raise Exception("Nothing to update, because query parameter is empty")
          
# Create method to implement the D in CRUD.
    def delete(self, query):
        if query is not None:
            deletedRecord = self.collection.delete_many(query)
            return deletedRecord.deleted_count
        else:
            raise Exception("Nothing to delete, because query parameter is empty")
